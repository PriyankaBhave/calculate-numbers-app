var mongojs = require('mongojs');
var db = mongojs('calculateddatadb', ['calculatedresult']);
module.exports = db;