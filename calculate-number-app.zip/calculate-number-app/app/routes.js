var bodyParser = require('body-parser');
var db = require('./config/database');
var calculateModels = require('./models/calculateModels');

module.exports = function(app) {
    app.use(bodyParser.json());

    app.get('/getData', function(req, res) {

        var cal = calculateModels.getCalculatedData();
        cal.then(function(calculatedData) {
            res.send(calculatedData);
        }, function(err) {
            console.log(err);
        });
    });

    app.post('/saveData', function(req, res) {
        var cal = calculateModels.saveCalculatedData(req);
        cal.then(function(calculatedData) {
            res.send(calculatedData);
        }, function(err) {
            console.log(err);
        });
    });

}