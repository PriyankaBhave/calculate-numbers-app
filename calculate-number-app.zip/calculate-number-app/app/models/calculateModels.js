var db = require('../config/database');
module.exports.getCalculatedData = function(request) {
    var response = {};
    return new Promise(function(resolve, reject) {

        db.calculatedresult.find(function(error, document) {

            if (error)
                reject(error)
            else {
                if (document.length) {
                    response["success"] = true;
                    response["results"] = document;
                } else {
                    response["success"] = false;
                    response["results"] = "No records";
                }
                resolve(response);
            }
        });

    });
}

module.exports.saveCalculatedData = function(req) {
    var data = req.body;
    return new Promise(function(resolve, reject) {
        db.calculatedresult.insert(data, function(error, response) {
            if (error)
                reject(err);
            else {
                resolve({ success: true, result: 'Document Inserted' });
            }
        });
    });
}