Calculate Numbers API
---------------------------------------------------------------------------------------------

# Installation

* download from github[https://github.com/PriyankaBhave/calculate-numbers-app.git]

# start

* Open terminal
* move to directory.
* Run command "sudo npm install"

# Setup Database

* Install mongodb client and start the server.

# Run the application

* Run command "node server"

# Test Application

* Run command "npm test"

# Prerequisites

* NPM
* Node
* Mongodb
