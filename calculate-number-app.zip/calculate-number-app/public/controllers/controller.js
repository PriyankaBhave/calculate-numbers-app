app.controller('appCtrl', function($scope, $http) {

    $scope.filterValue = function($event) {
        $scope.class = "test";
        if (isNaN(String.fromCharCode($event.keyCode))) {

            $event.preventDefault();
        }
    };

    $http.get('/getData').success(function(response) {
        $scope.calculatedData = [];
        if (response.success) {
            $scope.calculatedData = response.results;
        }
    })

    $scope.calculateandsave = function() {
        if ($scope.input1 > 0 && $scope.input2 > 0) {
            $scope.calculated = $scope.input1 * $scope.input2;
            var requestParam = {
                input1: $scope.input1,
                input2: $scope.input2,
                result: $scope.calculated
            };
            $http.post('/saveData', requestParam)
                .success(function(response) {
                    if (response.success) {
                        $scope.input1 = null;
                        $scope.input2 = null;
                        $scope.dataSaved = true;
                    }
                });
        }
    }

});