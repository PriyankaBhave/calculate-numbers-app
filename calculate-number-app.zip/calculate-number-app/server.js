var express = require('express');
var app = express();
var mongojs = require('mongojs');

app.use(express.static(__dirname + '/public'));
// app.use('/angular-messages', express.static(__dirname, '/node_modules'));

var apiRoutes = require('./app/routes');

apiRoutes(app);
app.listen(3000);

console.log("Server running on port 3000");
console.log("http://localhost:3000/");